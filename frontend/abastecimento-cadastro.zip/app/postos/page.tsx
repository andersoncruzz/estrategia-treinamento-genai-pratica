import PostosPage from "../../postos"

export default function Page() {
  return <PostosPage />
}
