import CondutoresPage from "../../condutores"

export default function Page() {
  return <CondutoresPage />
}
