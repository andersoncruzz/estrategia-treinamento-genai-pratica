import Dashboard from "../dashboard"

export default function Page() {
  return <Dashboard />
}
