import CombustiveisPage from "../../combustiveis"

export default function Page() {
  return <CombustiveisPage />
}
