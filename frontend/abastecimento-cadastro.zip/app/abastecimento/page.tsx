import AbastecimentoPage from "../../abastecimento"

export default function Page() {
  return <AbastecimentoPage />
}
